tfbs.qsam
=========

R package for transcription factor binding site analysis using QSAM-representation of DNA sequences
